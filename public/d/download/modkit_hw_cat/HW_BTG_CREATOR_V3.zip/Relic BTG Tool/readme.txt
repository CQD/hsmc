BTG
---
The Background Tool of the Geeks

Installation:

To install the BTG, extract the contents of the zipfile into a
a directory on your hard drive, such as "c:\btg".  Be sure you
extract pathnames as well; the BTG needs to access its bitmaps and
undo directories exactly as placed in the .zip.

You can then simply run BTG.exe, and start editing backgrounds.
Check out btg.doc for information on how to use the tool itself.

Note: any backgrounds you work on must be present in the same
directory as BTG.exe, ie. "c:\btg".  Sorry - we made the mistake
of writing the BTG using MFC (Microsoft Foundation Classes), and
boy did we pay the price.  Try saving to a read-only file and
you'll get a helpful "File Not Found" error message, MFC's default
for all file-related errors.  Argh.
