die "Incorrect number of arguments.\n" if ( $#ARGV != 1 );

$_ = $ARGV[0];
s/\//\\/g;
$inFname = $_;

$_ = $ARGV[1];
s/\//\\/g;
$outFname = $_;

system( "copy $inFname $outFname" );



