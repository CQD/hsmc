SpookyRAT (Spooky's Relic Archive Tool) v2.0.0 Readme
=====================================================

Contents
--------
This archive contains the following files:
SpookyRAT.exe
LuaDC.dll
zlib.dll
comdlg32.ocx
mscomctl.ocx
SpookyRAT Readme.txt

Installation Notes
------------------
First and foremost you will need to download and install the Microsoft VB6 SP5 runtime files. These are available from Microsoft's site.

Then the DLL and OCX files in this archive should be copied to your windows\system32 directory. LuaDC.dll, comdlg32.ocx and mscomctl.ocx will then need registering. To do this the following technique should be used:

Start->Run...
cmd
cd c:\windows\system32
regsvr32 luadc.dll
regsvr32 comdlg32.ocx
regsvr32 mscomctl.ocx

Version History
---------------
v2.0.0 - Added Dawn of War compatability
v1.7.0 - Added ability to decompile HW2 lua files
...
v1.0.0 - Initial version

General Information
-------------------
This tool allows you to open all the .big, .sga, .grm1 files that hold the game data in Homeworld, Homeworld Cataclysm, Homeworld2, Impossible Creatures and Warhammer 40K: Dawn of War. In addition the contents of all bar the Homeworld .big files can be extracted. Homeworld2 uses compiled .lua files and these may be decompiled from within the application as well.

Do not mirror this application without my express permission. For starters you will miss out on updates. The latest versions of all my tools may be found at www.b5mods.com - home of the Great Wars Team.

If you have any questions/problems please post them in the relevant threads at forums.relicnews.com

Enjoy
Steve