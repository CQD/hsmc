Homeworld: Cataclysm Custom Map

====================
Creator: Dylov (Grunter-OMO on WON)
E-Mail Address:  dylov@ntlworld.com

Map Name:  Arachne
File Name:  CatArachne.zip
Version:  2.0 (27 November 2000)
Created With:  Excel2000, TextPad v.4.4, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

In Greek Mythology, a Lydian girl who was so skilful a weaver that she challenged the goddess Athena to a contest. Athena tore Arachne's beautiful tapestries to pieces and Arachne hanged herself. She was transformed into a spider, and her weaving became a cobweb.

Increasing Resources will draw players to the deadly centre of this huge web... 

Version 2.0 of Arachne, updated for cataclysm, added some crystals in the centre, decreased the overall size of the map. The background and lighting files are 'ez07.btg' and 'ez07.hsf' from the original Homeworld release.

*************

This map has three seperate designs for team or FFA bash for 2-4 players, 4-6 players and 6-8 players.

In order to play this may, unzip it into your SIERRA\Homeworld\Multiplayer folder. It should have Three folders named Arachne4, Arachne6 and Arachne8 plus this text file. If you have properly placed the folders, Homeworld will automatically recognize these maps on startup when you select Multiplayer maps.
