Homeworld: Cataclysm Custom Map

====================
Creator: Relic
HW:C Port: Dylov
E-Mail Address:  dylov@ntlworld.com

Map Name:  Scattered
File Name:  Scattered.zip
Version:  1.1 (28 October 2000)
Created With:  Excel2000, TextPad v.4.3.1:32-Bit Edition, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

The annals of history will only remember the cunning of the victor, the defeated shall have their atoms scattered to the corners of the universe, lost and forgotten. A very large map with resource pockets scattered about.  Good for players who enjoy longer games.

This map and its background are from the original Relic Map "Scattered", ported directly from Homeworld. Thanks to /Downslope\ for his insistence.

Background and lighting is 'ez04' by Relic, from the original HW release.

*************

In order to play this may, unzip it into your SIERRA\Cataclysm\Multiplayer folder. It should have three folders named Scattered4, Scattered6 and Scattered8 plus this text file. If you have properly placed the folders, Cataclysm will automatically recognize this map on startup when you select Multiplayer maps.

