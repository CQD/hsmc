Homeworld Custom Map

====================
Creator: Relic
HW:C Port: Dylov
E-Mail Address:  dylov@ntlworld.com

Map Name:  Hyperspace Arena
File Name:  hyperspacearena.zip
Version:  1.1 (28 October 2000)
Created With:  Excel2000, TextPad v.4.3.1:32-Bit Edition, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

A huge map designed for advanced players.  Dispersed but resource-rich pockets encourage hyperspacing.  The starting fleet includes, 3 Workers and 1 Processor.

This map and its background are from the original Relic Map "Hyperspace Arena", ported directly from Homeworld. Thanks to /Downslope\ for his insistence. I took the liberty of not adding in the frigates as per the original HW version, to keep racial purity of both beast and Somtaaw.

Background is 'ez05' by Relic, from the original HW release.

*************

In order to play this may, unzip it into your SIERRA\Cataclysm\Multiplayer folder. It should have Threefolders named hyperspacearena4, hyperspacearena6 and hyperspacearena8 plus this text file. If you have properly placed the folders, Cataclysm will automatically recognize this map on startup when you select Multiplayer maps.

