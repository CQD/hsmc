Homeworld: Cataclysm Custom Map

====================
Creator: Dylov
E-Mail Address:  dy.lov@techemail.com

Map Name:  Ringed World [No Gates]
File Name:  RingedNG.zip
Version:  2.0 (24 November 2000)
Created With:  Excel2000, TextPad v.4.4.2:32-Bit Edition, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

The 'No-Gates version of 'Ringed World' Inspired by 'TvB' and subtitled 'Team Wars III' This map is based on the precept by Geritol-OMO, all players start together and move outwards towards the resources... Choose your sides in this planetary system.

Background is 'inhyperspace' by Gnon
Lighting is 'ez07' by Relic, from the original HW release.

*************

In order to play this may, unzip it into your SIERRA\Cataclysm\Multiplayer folder. It should have Three folders named RingedNG4, RingedNG6 and RingedNG8 plus this text file. If you have properly placed the folders, Homeworld will automatically recognize this map on startup when you select Multiplayer maps.

