Homeworld: Cataclysm Custom Map

====================
Creator: Dylov
E-Mail Address:  dylov@ntlworld.com

Map Name:  Ringed World [No Gates]
File Name:  RingedNG.zip
Version:  2.2 (25 November 2000)
Created With:  Excel2000, TextPad v.4.4.2:32-Bit Edition, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

The 'No-Gates version of 'Ringed World' Inspired by 'TvB' and subtitled 'Team Wars III' This map is based on the precept by Geritol-OMO, all players start together and move outwards towards the resources... Choose your sides in this planetary system.

*************

In order to play this may, unzip it into your SIERRA\Cataclysm\Multiplayer folder. It should have One folder named RingedNG, plus this text file. If you have properly placed the folders, Cataclsm will automatically recognize this map on startup when you select Multiplayer maps.

