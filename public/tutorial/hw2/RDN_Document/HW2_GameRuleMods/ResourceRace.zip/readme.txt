Resource Race Source Data

This file contains the data and scripts needed to build the Resource Race Game Rules mod.

To build Resource Race, uncompress this file to some directory (such as c:\Games\Homeworld2).  Next, edit ResourceRace.bat and data\LevelData\Multiplayer\ResourceRace\ResourceRace.list.  Search-replace X:\Homeworld2 with the directory you unzipped to.  Finally, run the ResoureRace.bat.


